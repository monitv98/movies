import { Injectable } from "@angular/core";
import {
  HttpClient,
  HttpHeaders,
  HttpErrorResponse,
} from "@angular/common/http";
import { Bicycle } from "../models/bicycle";
import { Observable, of } from "rxjs";
import { catchError, tap, map } from "rxjs/operators";

const httpOptions = {
  headers: new HttpHeaders({ "Content-Type": "application/json" }),
};
const apiUrl = "http://localhost:8080/api/bicycles/";

@Injectable({
  providedIn: "root",
})
export class BicycleService {
  constructor(private http: HttpClient) {}

  getAll(): Observable<Bicycle[]> {
    return this.http.get<Bicycle[]>(apiUrl).pipe(
      tap((product) => console.log("fetched products")),
      catchError(this.handleError("getProducts", []))
    );
  }

  // getBicycle(id: any): Observable<Bicycle> {
  //   const url = `${apiUrl}/${id}`;
  //   return this.http.get<Bicycle>(url).pipe(
  //     tap(() => console.log(`fetched bicycle id=${id}`)),
  //     catchError(this.handleError<Bicycle>(`getProduct id=${id}`))
  //   );
  // }

  private handleError<T>(operation = "operation", result?: T) {
    return (error: any): Observable<T> => {
      console.error(error); // log to console instead
      return of(result as T);
    };
  }
}
