export class Bicycle {
  id: number;
  model: string;
  brand: string;
}